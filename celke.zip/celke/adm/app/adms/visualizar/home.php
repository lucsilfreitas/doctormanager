<?php
if(!isset($seg)){
    exit;
}
echo "Bem vindo a HOME<br>";

