<?php
if (!isset($seg)){
    exit;
}

echo "Cadastrar usuário";